import React, { Component } from "react";
import "./Home.css";

export default class Home extends React.Component {
  render() {
    return (
      <div className="Home">
        <div className="lander">
          <h1>Peachy</h1>
          <p>GUI/DB Fitness App</p>
        </div>
      </div>
    );
  }
}
