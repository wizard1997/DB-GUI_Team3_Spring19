export class WorkoutPlan {
    constructor(name, type, calories, setTime, comment, date) {
        this.name = name;
        this.type = type;
        this.calories = calories;
        this.setTime = setTime;
        this.comment = comment;       
        this.date = date;
    }
}
export default WorkoutPlan; 