export class Food {
    constructor(name,type, calories,date,details) {
this.name=name;
this.type=type;
this.calories = calories;
this.date=date;
this.details = details;
    }
}
export default Food;